## Проверка пакета `synthetic-expert1-20261028`
Ошибок: 0; предупреждений: 0; вопросов эксперту: 9.
- **needs_expert_review / SECONDARY_SOURCE** `document.source_url`: Источник документа не является разрешённым официальным порталом; требуется подтверждение по первичному источнику.
- **needs_expert_review / UNKNOWN_EFFECTIVE_DATE** `amendments[0].effective_date`: Дата вступления в силу не подтверждена.
- **needs_expert_review / MISSING_COORDINATE** `amendments[0].changes[0].source_locator`: Нет точной координаты изменения в источнике.
- **needs_expert_review / NO_EXPERT_APPROVAL** `extraction.expert_approved`: Человеческое одобрение результата не подтверждено.
- **needs_expert_review / EFFECTIVE_DATE_UNVERIFIED** `amendments[0].effective_date`: Дату вступления в силу нужно сверить с текстом акта и переходными положениями.
- **needs_expert_review / EDITION_SEQUENCE_UNVERIFIED** `amendments[0]`: Порядок редакций и возможные промежуточные изменения требует экспертной сверки.
- **needs_expert_review / CHANGE_TYPE_UNVERIFIED** `amendments[0].changes[0].type`: Вид правки нужно подтвердить по формулировке изменяющего акта.
- **needs_expert_review / NON_OFFICIAL_SOURCE** `amendments[0].changes[0]`: Нужна ссылка на официальный первичный источник.
- **needs_expert_review / COMPLETENESS_UNVERIFIED** `amendments`: Полнота перечня редакций требует сверки с официальным реестром и подтверждения эксперта.
