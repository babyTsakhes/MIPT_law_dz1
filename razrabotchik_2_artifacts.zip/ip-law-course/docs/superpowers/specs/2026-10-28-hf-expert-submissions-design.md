# Expert submissions to Hugging Face: design

## Intent

Give legal experts a repeatable way to submit a reviewed history YAML and its
YAML/JSON session transcript as one Hugging Face dataset pull request. The
recipient can inspect provenance and request corrections before any record is
included in a curated dataset.

## Scope and constraints

- This is the intake side owned by developer 1. Schema and legal-content review,
  approval, and curated dataset assembly belong to developer 2 and experts.
- The course's existing `amendment` JSONL schema describes individual article
  events. An entire history YAML cannot be silently treated as those records.
- The current researcher 2 handoff is `proposed`: it explicitly lacks human
  expert approval and has unresolved effective dates and edition completeness.
- The intake repository is separate from the curated dataset. The existing
  calibration and amendment files already cause a mixed-schema viewer error in
  the current public dataset.
- No token is stored in source files, arguments, manifests, or logs. The CLI
  takes `HF_TOKEN` from the environment or prompts with hidden input.

## Chosen approach

Use a single Python CLI backed by `huggingface_hub` and `PyYAML`. It validates
and packages three source files under `submissions/<submission-id>/`, adds a
transport `manifest.json` containing identity, status, filenames, and SHA-256
hashes, and submits all four files in one Hub commit. The first call creates a
PR. An explicit `--pr` commits a corrected package to that open PR.

`--dry-run` is local and the default. `--submit` explicitly starts a network
write. Raw session files are not edited; the CLI rejects obvious credentials
and private-key material and requires the expert to review public content.
Unknown legal facts remain unknown. There is no automatic YAML-to-JSONL
conversion or approval.

## Approaches considered

1. **Direct Hugging Face PR (chosen):** matches the new team assignment and
   has already passed a smoke test on a personal dataset. Hub PRs are refs on
   the repository; follow-up commits use `refs/pr/N`.
2. **GitHub PR then publish:** already exists in the course, but it accepts
   individual JSONL records rather than complete YAML histories and does not
   meet the explicit direct-Hub PR request.
3. **Direct upload to main:** simplest technically, but bypasses review.

## Interface with developer 2

Developer 2 reads a stable package and manifest, validates the history and
session, writes review findings to the PR, and later converts approved events
to the course's canonical record format. A proposed package may be reviewed
but must not be automatically merged into the curated dataset.

## Success

One fixture passes local checks, opens a Hub PR, receives a corrected commit in
the same PR, and leaves `main` untouched. The expert guide explains both
commands and the contract. Actual research files remain pending until human
review and the developer 2 validator are ready.
