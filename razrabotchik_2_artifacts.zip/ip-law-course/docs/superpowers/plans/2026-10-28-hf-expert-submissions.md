# Hugging Face expert submissions implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Package a legal history and session pair and open or update one Hugging Face dataset PR.

**Architecture:** A focused Python module handles package validation and creation. A small CLI handles arguments, credentials, and Hub commits. Documentation and a synthetic fixture show the expert workflow.

**Tech Stack:** Python 3.12, PyYAML, huggingface_hub, unittest.

**Spec:** `docs/superpowers/specs/2026-10-28-hf-expert-submissions-design.md`

## Global constraints

- Keep intake separate from curated publication.
- Preserve unknown legal values and status `proposed`.
- Do not print or write tokens.
- The input session YAML and JSON must represent the same object.
- Follow-up uploads must target an existing open PR in the same dataset.

## Review focus

- Mismatched session YAML/JSON must fail before network access.
- Session or history content containing a token must fail without echoing it.
- An incorrect history count or session hash must fail clearly.
- A closed or non-PR discussion must not be updated.
- A second upload to an open PR must use `refs/pr/N`, not create another PR.

---

### Task 1: Package contract and local validation

**Files:** `expert_submissions/package.py`, `tests/test_expert_submissions.py`

**Interfaces:** `build_package(history_path, session_yaml_path, session_json_path, submission_id, expert_id) -> Package`; `Package` exposes Hub paths and bytes.

- [x] Write tests for valid package, mismatch, secret rejection, count/hash mismatch, and unsafe IDs.
- [x] Run tests and observe failures because the module is absent.
- [x] Implement package parsing, checks, and manifest assembly.
- [x] Run tests to green.

### Task 2: CLI and Hub PR lifecycle

**Files:** `expert_submissions/submit.py`, `tests/test_expert_submissions_cli.py`, `expert_submissions/requirements.txt`

**Interfaces:** `submit_package(package, repo_id, token, pr=None, api=None) -> str`; CLI defaults to dry-run and requires `--submit` for writes.

- [x] Write tests for first PR, update in the same PR, closed/non-PR rejection, and no network on dry-run.
- [x] Run tests and observe failures because the CLI is absent.
- [x] Implement the CLI with hidden token entry or `HF_TOKEN`, no token logging.
- [x] Run tests to green.

### Task 3: Expert guide and live transport check

**Files:** `expert_submissions/README.md`, `expert_submissions/examples/`, `CONTRIBUTING.md`

- [x] Document directory layout, naming, review status, credentials, dry-run, submit, and PR correction.
- [x] Validate the synthetic example locally.
- [x] Open a PR in `Andrewwert4567/ip-law-submission-test` and update it once.
- [x] Run the full repository tests and inspect the PR and branch diff.
