"""Build a curated dataset from trusted human approvals and immutable HF PRs."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from typing import Callable

from huggingface_hub import CommitOperationAdd, HfApi, hf_hub_download
from jsonschema import Draft202012Validator, FormatChecker

from .curated import ApprovalError, build_curated, convert_approved
from .review_validate import validate_pr_package
from .source_review import fetch_official_text


def prepare_all(
    approvals: list[dict],
    *,
    api: HfApi,
    load_file: Callable[[str, str, str], bytes],
    fetcher: Callable[[str], bytes],
    work_dir: Path,
) -> tuple[bytes, dict, dict[str, bytes]]:
    """Re-fetch every approved PR and evidence source before conversion."""
    if not approvals:
        raise ApprovalError("no human approvals supplied")
    schema = json.loads((Path(__file__).parent / "approval.schema.json").read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    work_dir = Path(work_dir).resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    groups: list[tuple[str, str, list[dict]]] = []
    source_files: dict[str, bytes] = {}
    for approval in approvals:
        if list(validator.iter_errors(approval)):
            raise ApprovalError("approval does not match schema")
        repo, pr, sha = approval["intake_repo_id"], approval["pr_number"], approval["source_revision"]
        details = api.get_discussion_details(repo_id=repo, repo_type="dataset", discussion_num=pr)
        if not details.is_pull_request or details.status != "open":
            raise ApprovalError("approved source must be an open PR")
        current = api.repo_info(repo_id=repo, repo_type="dataset", revision=f"refs/pr/{pr}").sha
        if current != sha:
            raise ApprovalError("approval revision is stale")
        prefix = f"submissions/{approval['submission_id']}/"
        paths = set(api.list_repo_files(repo_id=repo, repo_type="dataset", revision=sha))
        names = ("history.yaml", "session.yaml", "session.json", "manifest.json")
        if any(prefix + name not in paths for name in names):
            raise ApprovalError("approved PR does not contain the package")
        files = {prefix + name: load_file(repo, prefix + name, sha) for name in names}
        report = validate_pr_package(files, source_revision=sha)
        if report.has_errors:
            raise ApprovalError("approved package has structural errors")
        for item in approval["accepted_changes"]:
            relative = Path(item["source_file"])
            if relative.is_absolute() or not relative.parts or relative.parts[0] != "sources" or ".." in relative.parts:
                raise ApprovalError("source_file must be a safe path under sources/")
            destination = (work_dir / relative).resolve()
            if not destination.is_relative_to(work_dir):
                raise ApprovalError("source_file escapes work directory")
            data = fetcher(item["source_url"])
            if hashlib.sha256(data).hexdigest() != item["source_sha256"]:
                raise ApprovalError("source evidence hash differs from approved hash")
            if item["source_file"] in source_files and source_files[item["source_file"]] != data:
                raise ApprovalError("two approved sources use one path with different contents")
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            source_files[item["source_file"]] = data
        records = convert_approved(files, report, approval, work_dir)
        groups.append((approval["submission_id"], sha, records, {
            "intake_repo_id": repo, "pr_number": pr, "approved_at": approval["approved_at"],
            "files": {name: hashlib.sha256(files[prefix + name]).hexdigest() for name in names},
        }))
    data, manifest = build_curated(groups)
    return data, manifest, source_files


def publish_curated(
    data: bytes,
    manifest: dict,
    source_files: dict[str, bytes],
    *,
    target_repo_id: str,
    intake_repo_ids: set[str],
    api: HfApi,
    load_target: Callable[[str], bytes],
) -> str:
    """Publish an additive version; same bytes are a no-op, prior records survive."""
    if target_repo_id in intake_repo_ids or target_repo_id == "lawful-good-project/legal-agent-calibrations":
        raise ValueError("curated target must be separate from intake and mixed-schema datasets")
    files = set(api.list_repo_files(repo_id=target_repo_id, repo_type="dataset", revision="main"))
    for path, content in source_files.items():
        if path in files and load_target(path) != content:
            raise ApprovalError("curated update would silently change an existing source")
    if "manifest.json" in files:
        previous_manifest = json.loads(load_target("manifest.json"))
        if previous_manifest.get("records_sha256") == manifest["records_sha256"] and all(path in files for path in source_files):
            return f"https://huggingface.co/datasets/{target_repo_id}/tree/main"
    if "data/records.jsonl" in files:
        previous = {r["record_id"]: r for r in (json.loads(line) for line in load_target("data/records.jsonl").splitlines() if line)}
        current = {r["record_id"]: r for r in (json.loads(line) for line in data.splitlines() if line)}
        if any(key not in current or current[key] != value for key, value in previous.items()):
            raise ApprovalError("curated update would delete or silently change an existing record")
    manifest_data = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    version = manifest["version"]
    operations = [
        CommitOperationAdd(path_in_repo="data/records.jsonl", path_or_fileobj=data),
        CommitOperationAdd(path_in_repo="manifest.json", path_or_fileobj=manifest_data),
        CommitOperationAdd(path_in_repo=f"versions/{version}/records.jsonl", path_or_fileobj=data),
        CommitOperationAdd(path_in_repo=f"versions/{version}/manifest.json", path_or_fileobj=manifest_data),
    ]
    operations.extend(CommitOperationAdd(path_in_repo=path, path_or_fileobj=content)
                      for path, content in sorted(source_files.items()))
    result = api.create_commit(repo_id=target_repo_id, repo_type="dataset", revision="main",
                               operations=operations, commit_message=f"Publish approved amendment dataset {version}")
    return result.commit_url


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--approval-dir", required=True, help="trusted approvals from a protected code repository")
    parser.add_argument("--target-repo-id", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--publish", action="store_true", help="write to target dataset; default is dry-run")
    args = parser.parse_args(argv)
    approval_paths = sorted(Path(args.approval_dir).glob("*.json"))
    if not approval_paths:
        print("No human approvals; nothing to publish.")
        return 0
    try:
        approvals = [json.loads(path.read_text(encoding="utf-8")) for path in approval_paths]
        token = os.environ.get("HF_TOKEN")
        if args.publish and not token:
            raise ApprovalError("HF_TOKEN required for publishing")
        api = HfApi(token=token)
        def load_file(repo: str, path: str, revision: str) -> bytes:
            return Path(hf_hub_download(repo_id=repo, repo_type="dataset", filename=path,
                                        revision=revision, token=token)).read_bytes()
        output = Path(args.out_dir)
        data, manifest, sources = prepare_all(approvals, api=api, load_file=load_file,
                                              fetcher=fetch_official_text, work_dir=output)
        (output / "data").mkdir(parents=True, exist_ok=True)
        (output / "data/records.jsonl").write_bytes(data)
        (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"Prepared {manifest['record_count']} records, version {manifest['version']}.")
        if args.publish:
            def load_target(path: str) -> bytes:
                return Path(hf_hub_download(repo_id=args.target_repo_id, repo_type="dataset",
                                            filename=path, revision="main", token=token)).read_bytes()
            url = publish_curated(data, manifest, sources, target_repo_id=args.target_repo_id,
                                  intake_repo_ids={a["intake_repo_id"] for a in approvals},
                                  api=api, load_target=load_target)
            print(f"Published: {url}")
        return 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        # Hub and parser exceptions may contain URLs or raw content; do not echo them.
        print(f"Build failed: {type(exc).__name__}.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
