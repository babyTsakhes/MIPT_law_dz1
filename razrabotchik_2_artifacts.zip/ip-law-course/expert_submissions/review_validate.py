"""Deterministic second-pass validation of a Hugging Face PR package."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from datetime import date
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from jsonschema import Draft202012Validator, FormatChecker

from .package import ID_PATTERN, PackageError, SECRET_PATTERNS, _json_object, _same_data, _yaml_object


@dataclass(frozen=True)
class Finding:
    severity: str
    code: str
    path: str
    message: str


@dataclass
class ReviewReport:
    submission_id: str | None = None
    source_revision: str | None = None
    findings: list[Finding] = field(default_factory=list)

    @property
    def has_errors(self) -> bool:
        return any(item.severity == "error" for item in self.findings)

    def add(self, severity: str, code: str, path: str, message: str) -> None:
        self.findings.append(Finding(severity, code, path, message))

    def as_dict(self) -> dict[str, Any]:
        return {
            "format_version": 1,
            "submission_id": self.submission_id,
            "source_revision": self.source_revision,
            "findings": [asdict(item) for item in self.findings],
            "summary": {
                "errors": sum(x.severity == "error" for x in self.findings),
                "warnings": sum(x.severity == "warning" for x in self.findings),
                "needs_expert_review": sum(x.severity == "needs_expert_review" for x in self.findings),
            },
        }

    def markdown(self, *, limit: int | None = None) -> str:
        summary = self.as_dict()["summary"]
        lines = [f"## Проверка пакета `{self.submission_id or 'не определён'}`",
                 f"Ошибок: {summary['errors']}; предупреждений: {summary['warnings']}; вопросов эксперту: {summary['needs_expert_review']}."]
        for item in self.findings[:limit] if limit is not None else self.findings:
            lines.append(f"- **{item.severity} / {item.code}** `{item.path}`: {item.message}")
        if limit is not None and len(self.findings) > limit:
            lines.append(f"- Ещё {len(self.findings) - limit} замечаний содержатся в полном JSON/Markdown-отчёте проверки.")
        return "\n".join(lines) + "\n"


def _schema(name: str) -> dict:
    return json.loads((Path(__file__).parent / name).read_text(encoding="utf-8"))


def _validate_schema(value: dict, name: str, prefix: str, report: ReviewReport) -> None:
    validator = Draft202012Validator(_schema(name), format_checker=FormatChecker())
    for error in sorted(validator.iter_errors(value), key=lambda e: list(map(str, e.absolute_path))):
        path = ".".join(str(part) for part in error.absolute_path)
        # jsonschema error.message may echo untrusted values or credentials.
        report.add("error", "SCHEMA", f"{prefix}.{path}".rstrip("."),
                   "Поле не соответствует схеме; проверьте тип, обязательность или допустимое значение.")


def _mismatch_path(a: Any, b: Any, prefix: str = "session") -> str | None:
    if type(a) is not type(b):
        return prefix
    if isinstance(a, dict):
        for key in sorted(a.keys() | b.keys(), key=str):
            next_path = f"{prefix}.{key}"
            if key not in a or key not in b:
                return next_path
            found = _mismatch_path(a[key], b[key], next_path)
            if found:
                return found
        return None
    if isinstance(a, list):
        if len(a) != len(b):
            return prefix
        for index, (left, right) in enumerate(zip(a, b)):
            found = _mismatch_path(left, right, f"{prefix}[{index}]")
            if found:
                return found
        return None
    return None if a == b else prefix


def _calendar_check(value: Any, path: str, report: ReviewReport) -> None:
    if value is None:
        return
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        report.add("error", "INVALID_DATE", path, "Ожидается дата YYYY-MM-DD или null.")
        return
    try:
        date.fromisoformat(value)
    except ValueError:
        report.add("error", "INVALID_DATE", path, "Такой календарной даты нет.")


def validate_pr_package(files: dict[str, bytes], *, source_revision: str | None = None) -> ReviewReport:
    """Validate exact PR bytes; unknown legal facts remain review questions."""
    report = ReviewReport(source_revision=source_revision)
    if not files:
        report.add("error", "MISSING_FILES", "submissions", "В PR нет пакета.")
        return report
    prefixes = {path.rsplit("/", 1)[0] for path in files}
    if len(prefixes) != 1 or not re.fullmatch(r"submissions/[a-z0-9][a-z0-9_-]{2,79}", next(iter(prefixes))):
        report.add("error", "PATHS", "submissions", "Ожидается один каталог submissions/<submission_id>.")
        return report
    prefix = next(iter(prefixes))
    report.submission_id = prefix.split("/", 1)[1]
    names = {path.rsplit("/", 1)[-1] for path in files}
    if names != {"history.yaml", "session.yaml", "session.json", "manifest.json"}:
        report.add("error", "MISSING_FILES", prefix, "Требуются ровно history.yaml, session.yaml, session.json и manifest.json.")
        return report
    parsed: dict[str, dict] = {}
    for name in sorted(names):
        raw = files[f"{prefix}/{name}"]
        if not isinstance(raw, bytes) or not raw or len(raw) > 20 * 1024 * 1024:
            report.add("error", "FILE_SIZE", name, "Файл пуст, слишком велик или не является байтами.")
            continue
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            report.add("error", "UTF8", name, "Файл должен быть в UTF-8.")
            continue
        if any(pattern.search(text) for pattern in SECRET_PATTERNS):
            report.add("error", "POSSIBLE_SECRET", name, "В файле обнаружен возможный токен или закрытый ключ; удалите его.")
            continue
        try:
            parsed[name] = _yaml_object(raw, name) if name.endswith(".yaml") else _json_object(raw, name)
        except (PackageError, ValueError, TypeError):
            report.add("error", "PARSE", name, "Файл не разбирается или содержит повтор ключа.")
    if len(parsed) != 4:
        return report
    manifest, history = parsed["manifest.json"], parsed["history.yaml"]
    session_yaml, session_json = parsed["session.yaml"], parsed["session.json"]
    _validate_schema(manifest, "manifest.schema.json", "manifest.json", report)
    _validate_schema(history, "history.schema.json", "history.yaml", report)
    _validate_schema(session_json, "session.schema.json", "session.json", report)
    if manifest.get("submission_id") != report.submission_id:
        report.add("error", "ID_MISMATCH", "manifest.json.submission_id", "ID манифеста не совпадает с путём.")
    if not ID_PATTERN.fullmatch(str(manifest.get("expert_id", ""))):
        report.add("error", "ID_MISMATCH", "manifest.json.expert_id", "Неверный идентификатор эксперта.")
    if not _same_data(session_yaml, session_json):
        report.add("error", "SESSION_MISMATCH", _mismatch_path(session_yaml, session_json) or "session", "YAML и JSON сессии различаются.")
    declared_files = manifest.get("files") if isinstance(manifest.get("files"), dict) else {}
    for name in ("history.yaml", "session.yaml", "session.json"):
        if declared_files.get(name) != hashlib.sha256(files[f"{prefix}/{name}"]).hexdigest():
            report.add("error", "HASH_MISMATCH", f"manifest.json.files.{name}", "SHA-256 не совпадает с содержимым файла.")
    amendments = history.get("amendments")
    if not isinstance(amendments, list):
        return report
    if manifest.get("amendment_count") != len(amendments):
        report.add("error", "COUNT_MISMATCH", "manifest.json.amendment_count", "Количество актов не совпадает.")
    total = sum(len(a.get("changes", [])) for a in amendments if isinstance(a, dict) and isinstance(a.get("changes"), list))
    if manifest.get("change_count") != total:
        report.add("error", "COUNT_MISMATCH", "manifest.json.change_count", "Количество изменений не совпадает.")
    extraction = history.get("extraction")
    if isinstance(extraction, dict):
        counts = extraction.get("counts")
        if isinstance(counts, dict) and counts.get("all_records") is not None and counts["all_records"] != total:
            report.add("error", "COUNT_MISMATCH", "history.yaml.extraction.counts.all_records", "Заявленное число изменений не совпадает с перечнем.")
    final_result = session_json.get("final_result")
    if isinstance(final_result, dict) and final_result.get("data_sha256") is not None:
        if final_result["data_sha256"] != hashlib.sha256(files[f"{prefix}/history.yaml"]).hexdigest():
            report.add("error", "HASH_MISMATCH", "session.final_result.data_sha256", "Хеш истории в сессии не совпадает с файлом.")
    document = history.get("document")
    if isinstance(document, dict):
        if manifest.get("document_title") != document.get("title"):
            report.add("error", "DOCUMENT_MISMATCH", "manifest.json.document_title", "Название документа не совпадает с историей.")
        if manifest.get("source_url") != document.get("source_url"):
            report.add("error", "DOCUMENT_MISMATCH", "manifest.json.source_url", "Ссылка документа не совпадает с историей.")
        if "original_date" in document:
            _calendar_check(document["original_date"], "document.original_date", report)
        url = document.get("source_url")
        if isinstance(url, str) and urlparse(url).hostname not in ("publication.pravo.gov.ru", "pravo.gov.ru"):
            report.add("needs_expert_review", "SECONDARY_SOURCE", "document.source_url", "Источник документа не является разрешённым официальным порталом; требуется подтверждение по первичному источнику.")
    ids: set[str] = set()
    change_ids: set[str] = set()
    semantic: set[tuple[str, str, str, str]] = set()
    for i, amendment in enumerate(amendments):
        if not isinstance(amendment, dict):
            continue
        base = f"amendments[{i}]"
        if "date" in amendment:
            _calendar_check(amendment["date"], f"{base}.date", report)
        if amendment.get("effective_date") is None:
            report.add("needs_expert_review", "UNKNOWN_EFFECTIVE_DATE", f"{base}.effective_date", "Дата вступления в силу не подтверждена.")
        else:
            _calendar_check(amendment["effective_date"], f"{base}.effective_date", report)
        aid = amendment.get("amendment_id")
        if aid is not None:
            if str(aid) in ids:
                report.add("error", "DUPLICATE_AMENDMENT_ID", f"{base}.amendment_id", "Повтор идентификатора акта.")
            ids.add(str(aid))
        changes = amendment.get("changes")
        if not isinstance(changes, list):
            continue
        for j, change in enumerate(changes):
            if not isinstance(change, dict):
                continue
            change_base = f"{base}.changes[{j}]"
            cid = change.get("change_id")
            if cid is not None:
                if str(cid) in change_ids:
                    report.add("error", "DUPLICATE_CHANGE_ID", f"{change_base}.change_id", "Повтор идентификатора изменения.")
                change_ids.add(str(cid))
            fingerprint = (str(amendment.get("source_number") or amendment.get("source_url") or ""),
                           str(change.get("article") or ""), str(change.get("type") or ""),
                           str(change.get("description") or ""))
            if fingerprint in semantic:
                report.add("warning", "POSSIBLE_DUPLICATE", change_base, "Возможный повтор изменения; проверьте вручную.")
            semantic.add(fingerprint)
            if not change.get("source_locator"):
                report.add("needs_expert_review", "MISSING_COORDINATE", f"{change_base}.source_locator", "Нет точной координаты изменения в источнике.")
            if change.get("article") is None:
                report.add("needs_expert_review", "UNLOCATED_TARGET", f"{change_base}.article", "Статья не определена; такую правку нельзя автоматически преобразовать в запись amendment.")
    if isinstance(extraction, dict) and extraction.get("expert_approved") is not True:
        report.add("needs_expert_review", "NO_EXPERT_APPROVAL", "extraction.expert_approved", "Человеческое одобрение результата не подтверждено.")
    return report
