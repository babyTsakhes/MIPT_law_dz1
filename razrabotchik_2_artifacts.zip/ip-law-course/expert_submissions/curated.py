"""Convert explicitly approved changes into the course amendment schema."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from urllib.parse import urlparse

from jsonschema import Draft202012Validator, FormatChecker

from .package import _json_object, _yaml_object
from .review_validate import ReviewReport, validate_pr_package
from .source_review import OFFICIAL_HOSTS


class ApprovalError(ValueError):
    """Approval is absent, stale, or lacks independently checked evidence."""


VALIDATOR_VERSION = "1.1.0"


def _normalized(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def convert_approved(files: dict[str, bytes], report: ReviewReport, approval: dict, corpus_root: Path) -> list[dict]:
    """Build records only from a trusted, revision-bound human approval file."""
    schema = json.loads((Path(__file__).parent / "approval.schema.json").read_text(encoding="utf-8"))
    if list(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(approval)):
        raise ApprovalError("approval file does not match its schema")
    if report.source_revision != approval["source_revision"]:
        raise ApprovalError("approval source revision differs from reviewed revision")
    fresh = validate_pr_package(files, source_revision=report.source_revision)
    if fresh.has_errors:
        raise ApprovalError("package has structural errors")
    if fresh.submission_id != approval["submission_id"]:
        raise ApprovalError("approval submission_id differs from package")
    prefix = f"submissions/{fresh.submission_id}/"
    history = _yaml_object(files[prefix + "history.yaml"], "history.yaml")
    manifest = _json_object(files[prefix + "manifest.json"], "manifest.json")
    lookup = {}
    for amendment in history["amendments"]:
        for change in amendment["changes"]:
            if "change_id" in change:
                key = str(change["change_id"])
                if key in lookup:
                    raise ApprovalError("duplicate change_id in package")
                lookup[key] = (amendment, change)
    accepted = approval["accepted_changes"]
    if len({str(item["change_id"]) for item in accepted}) != len(accepted):
        raise ApprovalError("duplicate accepted change_id")
    universal = json.loads((Path(__file__).parents[1] / "assignments/00-first-contribution/dataset-schema/universal-record.schema.json").read_text(encoding="utf-8"))
    validator = Draft202012Validator(universal, format_checker=FormatChecker())
    records = []
    corpus_root = Path(corpus_root).resolve()
    for item in accepted:
        change_id = str(item["change_id"])
        if change_id not in lookup:
            raise ApprovalError("accepted change_id is not present in package")
        amendment, change = lookup[change_id]
        article = change.get("article")
        if not isinstance(article, str) or not re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", article):
            raise ApprovalError("approved change has no unambiguous article number")
        if not re.search(rf"/ст\.{re.escape(article)}(?:/|$)", item["norm_id"]):
            raise ApprovalError("approved norm_id differs from article")
        if not isinstance(change.get("description"), str) or not change["description"].strip():
            raise ApprovalError("approved change needs a description")
        url = item["source_url"]
        if urlparse(url).scheme != "https" or urlparse(url).hostname not in OFFICIAL_HOSTS:
            raise ApprovalError("approved evidence must use an official HTTPS URL")
        if url not in (change.get("source_url"), amendment.get("source_url")):
            raise ApprovalError("approved source URL differs from change source")
        relative = Path(item["source_file"])
        if relative.is_absolute() or not relative.parts or relative.parts[0] != "sources" or ".." in relative.parts:
            raise ApprovalError("source_file must be a safe path under sources/")
        source_path = (corpus_root / item["source_file"]).resolve()
        if not source_path.is_relative_to(corpus_root) or not source_path.is_file():
            raise ApprovalError("source_file must exist inside corpus root")
        source_bytes = source_path.read_bytes()
        if hashlib.sha256(source_bytes).hexdigest() != item["source_sha256"]:
            raise ApprovalError("source file SHA-256 changed")
        source_text = _normalized(source_bytes.decode("utf-8", errors="replace"))
        quote_text = _normalized(item["evidence_quote"])
        coordinate_text = _normalized(item["source_coord"])
        if quote_text not in source_text:
            raise ApprovalError("evidence quote is absent from source file")
        coordinate_at = source_text.casefold().find(coordinate_text.casefold())
        if coordinate_at < 0 or quote_text not in source_text[coordinate_at:coordinate_at + 2000]:
            raise ApprovalError("source coordinate does not locate evidence quote")
        if isinstance(change.get("type"), str) and change["type"] in {
            "изменена", "дополнена", "введена", "изложена_в_новой_редакции",
            "признана_утратившей_силу", "исключена", "уточнена"
        } and change["type"] != item["predicate"]:
            raise ApprovalError("approved predicate differs from extracted change type")
        if amendment.get("effective_date") is not None and amendment["effective_date"] != item["effective_date"]:
            raise ApprovalError("approved effective date differs from extracted effective date")
        identity = [item["norm_id"], item["amending_doc"], item["predicate"], item["effective_date"]]
        record_id = "ip.amd." + hashlib.sha256(json.dumps(identity, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()[:16]
        record = {
            "schema": 1, "record_id": record_id, "profile": "amendment",
            "title_ru": history["document"]["title"],
            "norm": {"source_law": item["source_law"],
                     "article": f"ст.{article}", "norm_id": item["norm_id"]},
            "amending_doc": item["amending_doc"], "predicate": item["predicate"],
            "ts": item["effective_date"], "granularity": "day",
            "change_ru": change["description"], "evidence_quote": item["evidence_quote"],
            "source": {"file": item["source_file"], "coord": item["source_coord"],
                       "doc_type": "npa", "license": "official-document", "url": url},
            "provenance": {"extracted_by": manifest["expert_id"], "extracted_at": approval["extracted_at"],
                           "method": "assisted", "tool": "opencode"},
            "review": {"status": "verified", "reviewed_by": approval["approved_by"],
                       "reviewed_at": approval["approved_at"],
                       "note_ru": f"Approved from {fresh.submission_id} at {approval['source_revision'][:12]}"},
        }
        if list(validator.iter_errors(record)):
            raise ApprovalError("converted record does not match course schema")
        records.append(record)
    return sorted(records, key=lambda record: record["record_id"])


def build_curated(submissions: list[tuple]) -> tuple[bytes, dict]:
    """Deterministically assemble already verified records and provenance."""
    records: dict[str, dict] = {}
    sources = []
    input_packages = []
    build_dates = []
    for entry in sorted(submissions, key=lambda item: (item[0], item[1])):
        submission_id, revision, group = entry[:3]
        metadata = entry[3] if len(entry) > 3 else {}
        sources.append({"submission_id": submission_id, "revision": revision})
        if metadata:
            input_packages.append({"submission_id": submission_id, "revision": revision,
                                   "intake_repo_id": metadata["intake_repo_id"], "pr_number": metadata["pr_number"],
                                   "files": metadata["files"]})
            build_dates.append(metadata["approved_at"])
        for record in group:
            key = record["record_id"]
            if key in records:
                left = {k: v for k, v in records[key].items() if k not in ("provenance", "review")}
                right = {k: v for k, v in record.items() if k not in ("provenance", "review")}
                if left != right:
                    raise ApprovalError("conflicting duplicate legal change in curated build")
                continue
            if record.get("review", {}).get("status") != "verified":
                raise ApprovalError("curated build accepts verified records only")
            records[key] = record
    if not records:
        raise ApprovalError("no approved records to build")
    data = "".join(json.dumps(records[key], ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n" for key in sorted(records)).encode("utf-8")
    digest = hashlib.sha256(data).hexdigest()
    manifest = {"format_version": 1, "course_schema": 1, "validator_version": VALIDATOR_VERSION,
                "build_date": max(build_dates) if build_dates else None,
                "accepted_record_ids": sorted(records), "input_packages": input_packages,
                "record_count": len(records),
                "records_sha256": digest, "version": digest[:12],
                "sources": sorted(sources, key=lambda item: (item["submission_id"], item["revision"]))}
    return data, manifest
