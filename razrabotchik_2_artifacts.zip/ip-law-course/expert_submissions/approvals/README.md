# Human approval files

Only human experts may propose a JSON approval file here. Each file must follow
`../approval.schema.json`, identify one exact intake PR commit and list only
changes the expert checked against an official source. The PR that adds or edits
an approval must be reviewed by another trusted maintainer before merge to the
protected `main` branch. CI does not infer approval from chat text, a submitted
manifest, a model response, or the name of an expert in a session.

No real approval file is included yet. Synthetic test fixtures live in `tests/`.
