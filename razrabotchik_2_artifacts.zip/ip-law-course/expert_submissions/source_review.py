"""Evidence collector for official legal sources; it never grants approval."""

from __future__ import annotations

import hashlib
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import date
from html.parser import HTMLParser
from typing import Callable
from urllib.parse import urlparse

from .review_validate import ReviewReport


OFFICIAL_HOSTS = frozenset({"publication.pravo.gov.ru", "pravo.gov.ru"})


class _TextOnly(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self.hidden = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.hidden += 1

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self.hidden:
            self.hidden -= 1

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        return None


def fetch_official_text(url: str) -> bytes:
    """Fetch bounded official text without following redirects to other hosts."""
    parsed = urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in OFFICIAL_HOSTS or len(url) > 2048:
        raise ValueError("Only allowed official HTTPS sources may be fetched")
    opener = urllib.request.build_opener(_NoRedirect)
    request = urllib.request.Request(url, headers={"User-Agent": "ip-law-review/1.0"})
    with opener.open(request, timeout=15) as response:
        content_type = response.headers.get_content_type()
        if content_type not in ("text/html", "text/plain"):
            raise ValueError("Unsupported source content type")
        data = response.read(2 * 1024 * 1024 + 1)
        if len(data) > 2 * 1024 * 1024:
            raise ValueError("Source exceeds 2 MiB")
        charset = response.headers.get_content_charset() or "utf-8"
        text = data.decode(charset, errors="replace")
        if content_type == "text/html":
            parser = _TextOnly()
            parser.feed(text)
            text = " ".join(parser.parts)
        return re.sub(r"\s+", " ", text).strip().encode("utf-8")


def _normalized_text(data: bytes) -> str:
    text = data.decode("utf-8", errors="replace")
    if "<html" in text.lower():
        parser = _TextOnly()
        parser.feed(text)
        text = " ".join(parser.parts)
    return re.sub(r"\s+", " ", text).strip()


@dataclass
class SourceReview:
    report: ReviewReport = field(default_factory=ReviewReport)
    evidence: list[dict] = field(default_factory=list)


def review_sources(
    history: dict,
    *,
    fetcher: Callable[[str], bytes] = fetch_official_text,
    accessed_at: str | None = None,
) -> SourceReview:
    """Compare quoted text with official pages, recording what was checked."""
    result = SourceReview()
    accessed_at = accessed_at or date.today().isoformat()
    cache: dict[str, bytes | None] = {}
    for i, amendment in enumerate(history.get("amendments", [])):
        if not isinstance(amendment, dict):
            continue
        result.report.add("needs_expert_review", "EFFECTIVE_DATE_UNVERIFIED", f"amendments[{i}].effective_date",
                          "Дату вступления в силу нужно сверить с текстом акта и переходными положениями.")
        result.report.add("needs_expert_review", "EDITION_SEQUENCE_UNVERIFIED", f"amendments[{i}]",
                          "Порядок редакций и возможные промежуточные изменения требует экспертной сверки.")
        for j, change in enumerate(amendment.get("changes", [])):
            if not isinstance(change, dict):
                continue
            path = f"amendments[{i}].changes[{j}]"
            result.report.add("needs_expert_review", "CHANGE_TYPE_UNVERIFIED", f"{path}.type",
                              "Вид правки нужно подтвердить по формулировке изменяющего акта.")
            url = change.get("source_url") or amendment.get("source_url")
            if not isinstance(url, str) or urlparse(url).scheme != "https" or urlparse(url).hostname not in OFFICIAL_HOSTS:
                result.report.add("needs_expert_review", "NON_OFFICIAL_SOURCE", path,
                                  "Нужна ссылка на официальный первичный источник.")
                continue
            if url not in cache:
                try:
                    cache[url] = fetcher(url)
                except (OSError, ValueError, urllib.error.URLError):
                    cache[url] = None
            data = cache[url]
            if not data:
                result.report.add("needs_expert_review", "SOURCE_UNAVAILABLE", path,
                                  "Официальный источник недоступен или не может быть прочитан.")
                continue
            quote = change.get("new_text") or change.get("original_text")
            normalized = _normalized_text(data)
            act_number = amendment.get("source_number")
            if isinstance(act_number, str) and act_number.strip() and act_number not in normalized:
                result.report.add("needs_expert_review", "ACT_ID_NOT_FOUND", path,
                                  "Номер изменяющего акта не найден на полученной странице.")
            article = change.get("article")
            if isinstance(article, str) and article.isdigit() and not re.search(
                rf"(?:статья|ст\.)\s*{re.escape(article)}\b", normalized, flags=re.IGNORECASE
            ):
                result.report.add("needs_expert_review", "ARTICLE_NOT_FOUND", path,
                                  "Номер статьи не найден на полученной странице.")
            match = "not_provided" if not isinstance(quote, str) or not quote.strip() else (
                "exact" if re.sub(r"\s+", " ", quote).strip() in normalized else "missing"
            )
            result.evidence.append({
                "path": path, "url": url, "accessed_at": accessed_at,
                "source_sha256": hashlib.sha256(data).hexdigest(),
                "source_locator": change.get("source_locator"), "match": match,
            })
            if match == "missing":
                result.report.add("needs_expert_review", "QUOTE_NOT_FOUND", path,
                                  "Заявленный текст не найден на полученной странице источника.")
            elif match == "not_provided":
                result.report.add("needs_expert_review", "NO_QUOTE", path,
                                  "Нет фрагмента текста для машинной сверки.")
            else:
                result.report.add("needs_expert_review", "LEGAL_REVIEW_REQUIRED", path,
                                  "Текст найден; правовой смысл, редакцию и полноту должен подтвердить эксперт.")
    result.report.add("needs_expert_review", "COMPLETENESS_UNVERIFIED", "amendments",
                      "Полнота перечня редакций требует сверки с официальным реестром и подтверждения эксперта.")
    return result
