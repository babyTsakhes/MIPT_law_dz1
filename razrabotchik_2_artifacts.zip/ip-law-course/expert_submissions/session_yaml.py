"""Create a YAML view of a JSON session export without summarizing it."""

from __future__ import annotations

import argparse
from pathlib import Path

import yaml

from .package import _json_object, _read_input


def convert(source: Path, target: Path) -> None:
    session = _json_object(_read_input(source, "session.json"), "session.json")
    target.write_text(
        yaml.safe_dump(session, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path, help="session JSON export")
    parser.add_argument("target", type=Path, help="session YAML output")
    args = parser.parse_args()
    convert(args.source, args.target)
    print(f"YAML session written: {args.target}")


if __name__ == "__main__":
    main()
