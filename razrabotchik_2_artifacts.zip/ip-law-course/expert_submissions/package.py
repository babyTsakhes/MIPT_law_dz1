"""Build and check an expert submission without network side effects."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import yaml


ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_-]{2,79}$")
SECRET_PATTERNS = (
    re.compile(r"hf_[A-Za-z0-9]{20,}"),
    re.compile(r"sk-[A-Za-z0-9_-]{20,}"),
    re.compile(r"gh[pousr]_[A-Za-z0-9]{20,}"),
    re.compile(r"github_pat_[A-Za-z0-9_]{20,}"),
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
)


class PackageError(ValueError):
    """An input cannot be submitted safely or consistently."""


class _UniqueKeyLoader(yaml.SafeLoader):
    def construct_mapping(self, node, deep=False):
        keys = set()
        for key_node, _ in node.value:
            key = self.construct_object(key_node, deep=deep)
            if key in keys:
                raise PackageError("YAML: duplicate key")
            keys.add(key)
        return super().construct_mapping(node, deep=deep)


@dataclass(frozen=True)
class Package:
    submission_id: str
    files: dict[str, bytes]
    manifest: dict[str, Any]


def _read_input(path: Path, label: str) -> bytes:
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise PackageError(f"{label}: cannot read file") from exc
    if not data:
        raise PackageError(f"{label}: file is empty")
    if len(data) > 20 * 1024 * 1024:
        raise PackageError(f"{label}: file exceeds 20 MiB")
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise PackageError(f"{label}: expected UTF-8") from exc
    if any(pattern.search(text) for pattern in SECRET_PATTERNS):
        raise PackageError(f"{label}: possible credential detected; remove it before submission")
    return data


def _yaml_object(data: bytes, label: str) -> dict:
    try:
        value = yaml.load(data, Loader=_UniqueKeyLoader)
    except yaml.YAMLError as exc:
        raise PackageError(f"{label}: invalid YAML") from exc
    if not isinstance(value, dict):
        raise PackageError(f"{label}: top level must be an object")
    return value


def _json_object(data: bytes, label: str) -> dict:
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise PackageError("JSON: duplicate key")
            result[key] = value
        return result

    try:
        value = json.loads(data, object_pairs_hook=unique_pairs)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PackageError(f"{label}: invalid JSON") from exc
    if not isinstance(value, dict):
        raise PackageError(f"{label}: top level must be an object")
    return value


def _same_data(left: Any, right: Any) -> bool:
    """Compare parsed YAML and JSON without Python's bool/number coercion."""
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(
            _same_data(left[key], right[key]) for key in left
        )
    if isinstance(left, list):
        return len(left) == len(right) and all(
            _same_data(a, b) for a, b in zip(left, right)
        )
    return left == right


def build_package(
    history_path: Path,
    session_yaml_path: Path,
    session_json_path: Path,
    *,
    submission_id: str,
    expert_id: str,
) -> Package:
    """Validate source files and return exact repository paths and bytes."""
    if not ID_PATTERN.fullmatch(submission_id):
        raise PackageError("submission_id must be 3–80 lowercase ASCII letters, digits, _ or -")
    if not ID_PATTERN.fullmatch(expert_id):
        raise PackageError("expert_id must be 3–80 lowercase ASCII letters, digits, _ or -")

    source_files = {
        "history.yaml": _read_input(Path(history_path), "history.yaml"),
        "session.yaml": _read_input(Path(session_yaml_path), "session.yaml"),
        "session.json": _read_input(Path(session_json_path), "session.json"),
    }
    history = _yaml_object(source_files["history.yaml"], "history.yaml")
    session_yaml = _yaml_object(source_files["session.yaml"], "session.yaml")
    session_json = _json_object(source_files["session.json"], "session.json")
    if not _same_data(session_yaml, session_json):
        raise PackageError("Session YAML and JSON differ")

    document = history.get("document")
    if not isinstance(document, dict) or not isinstance(document.get("title"), str) or not document["title"].strip():
        raise PackageError("history.yaml: document.title is required")
    source_url = document.get("source_url")
    if not isinstance(source_url, str) or urlparse(source_url).scheme not in ("http", "https") or not urlparse(source_url).netloc:
        raise PackageError("history.yaml: document.source_url must be an HTTP URL")
    amendments = history.get("amendments")
    if not isinstance(amendments, list) or not amendments:
        raise PackageError("history.yaml: amendments must be a non-empty list")
    if any(not isinstance(item, dict) or not isinstance(item.get("changes"), list) for item in amendments):
        raise PackageError("history.yaml: each amendment needs a changes list")
    change_count = sum(len(item["changes"]) for item in amendments)
    if change_count == 0:
        raise PackageError("history.yaml: at least one change is required")
    extraction = history.get("extraction")
    if extraction is not None and not isinstance(extraction, dict):
        raise PackageError("history.yaml: extraction must be an object")
    counts = (extraction or {}).get("counts")
    if counts is not None and not isinstance(counts, dict):
        raise PackageError("history.yaml: extraction.counts must be an object")
    declared_count = (counts or {}).get("all_records")
    if declared_count is not None and declared_count != change_count:
        raise PackageError("history.yaml: extraction.counts.all_records does not match changes")
    final_result = session_json.get("final_result")
    if final_result is not None and not isinstance(final_result, dict):
        raise PackageError("session: final_result must be an object")
    declared_hash = (final_result or {}).get("data_sha256")
    actual_hash = hashlib.sha256(source_files["history.yaml"]).hexdigest()
    if declared_hash is not None and declared_hash != actual_hash:
        raise PackageError("session: final_result.data_sha256 does not match history.yaml")

    manifest = {
        "format_version": 1,
        "submission_id": submission_id,
        "expert_id": expert_id,
        "status": "proposed",
        "document_title": document["title"],
        "source_url": source_url,
        "amendment_count": len(amendments),
        "change_count": change_count,
        "files": {name: hashlib.sha256(data).hexdigest() for name, data in source_files.items()},
    }
    prefix = f"submissions/{submission_id}/"
    files = {prefix + name: data for name, data in source_files.items()}
    files[prefix + "manifest.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    return Package(submission_id=submission_id, files=files, manifest=manifest)
