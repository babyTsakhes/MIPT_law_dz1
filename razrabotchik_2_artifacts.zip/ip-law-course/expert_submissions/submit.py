"""Open or update one Hugging Face dataset PR for an expert package."""

from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
from pathlib import Path

from .package import Package, PackageError, build_package


class SubmitError(RuntimeError):
    """The requested PR operation is unsafe or failed."""


def submit_package(
    package: Package,
    repo_id: str,
    token: str,
    *,
    pr: int | None = None,
    api=None,
) -> str:
    """Commit the package to a new PR, or correct an existing open PR."""
    from huggingface_hub import CommitOperationAdd, HfApi

    if api is None:
        api = HfApi(token=token)
    revision = None
    if pr is not None:
        if pr < 1:
            raise SubmitError("PR number must be positive")
        details = api.get_discussion_details(
            repo_id=repo_id, discussion_num=pr, repo_type="dataset"
        )
        if not details.is_pull_request or details.status != "open":
            raise SubmitError("The selected discussion must be an open PR")
        revision = f"refs/pr/{pr}"
        files = api.list_repo_files(repo_id=repo_id, repo_type="dataset", revision=revision)
        expected_manifest = f"submissions/{package.submission_id}/manifest.json"
        if expected_manifest not in files:
            raise SubmitError("PR does not contain this submission_id")

    operations = [
        CommitOperationAdd(path_in_repo=path, path_or_fileobj=data)
        for path, data in sorted(package.files.items())
    ]
    result = api.create_commit(
        repo_id=repo_id,
        repo_type="dataset",
        operations=operations,
        commit_message=f"Submit legal history {package.submission_id}",
        commit_description="Expert intake package; status proposed until independent review.",
        revision=revision,
        create_pr=pr is None,
    )
    if pr is not None:
        return f"https://huggingface.co/datasets/{repo_id}/discussions/{pr}"
    if not result.pr_url:
        raise SubmitError("Hub did not return a PR URL")
    return result.pr_url


def main(argv: list[str] | None = None, *, api_factory=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", help="JSON config with paths and IDs, never a token")
    parser.add_argument("--history")
    parser.add_argument("--session-yaml")
    parser.add_argument("--session-json")
    parser.add_argument("--submission-id")
    parser.add_argument("--expert-id")
    parser.add_argument("--repo-id")
    parser.add_argument("--pr", type=int, help="update this existing open PR")
    parser.add_argument("--submit", action="store_true", help="write to Hugging Face; default is local dry-run")
    args = parser.parse_args(argv)

    fields = ("history", "session_yaml", "session_json", "submission_id", "expert_id", "repo_id")
    config = {}
    if args.config:
        try:
            config = json.loads(Path(args.config).read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError):
            print("Config must be a readable UTF-8 JSON file.", file=sys.stderr)
            return 1
        if not isinstance(config, dict) or set(config) - set(fields):
            print("Config contains unsupported fields; tokens are forbidden.", file=sys.stderr)
            return 1
    for field in fields:
        value = getattr(args, field) or config.get(field)
        if not isinstance(value, str) or not value:
            print(f"Missing --{field.replace('_', '-')} or config field {field}.", file=sys.stderr)
            return 1
        setattr(args, field, value)

    try:
        package = build_package(
            args.history, args.session_yaml, args.session_json,
            submission_id=args.submission_id, expert_id=args.expert_id,
        )
    except PackageError as exc:
        print(f"Input rejected: {exc}", file=sys.stderr)
        return 1

    print(f"Submission: {package.submission_id} ({package.manifest['status']})")
    print(f"Records: {package.manifest['change_count']} in {package.manifest['amendment_count']} acts")
    print(f"Target: {args.repo_id}")
    for path in sorted(package.files):
        print(f"  {path}")
    if not args.submit:
        print("Dry-run: no network write. Review all public session content before --submit.")
        return 0

    token = os.environ.get("HF_TOKEN", "").strip()
    if not token:
        try:
            token = getpass.getpass("HF token (hidden input): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nCancelled.", file=sys.stderr)
            return 1
    if not token:
        print("HF token is required for --submit.", file=sys.stderr)
        return 1
    try:
        api = api_factory(token) if api_factory is not None else None
        url = submit_package(package, args.repo_id, token, pr=args.pr, api=api)
    except SubmitError as exc:
        print(f"Submission failed: {exc}.", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"Submission failed: {type(exc).__name__}.", file=sys.stderr)
        return 1
    finally:
        token = ""
    print(f"PR: {url}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
