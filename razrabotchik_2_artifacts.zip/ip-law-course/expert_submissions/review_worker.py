"""Review an open Hugging Face dataset PR and optionally comment once per commit."""

from __future__ import annotations

import argparse
import json
import os
import re
from pathlib import Path
from typing import Callable

from huggingface_hub import HfApi, hf_hub_download

from .package import _yaml_object
from .review_validate import ReviewReport, validate_pr_package
from .source_review import review_sources


def process_pr(
    repo_id: str,
    pr: int,
    *,
    api: HfApi,
    load_file: Callable[[str, str], bytes],
    out_dir: Path,
    comment: bool = False,
    sources: bool = False,
    submission_id: str | None = None,
) -> ReviewReport:
    """Fetch immutable PR files, write reports, and comment idempotently."""
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo_id) or pr < 1:
        raise ValueError("Invalid dataset repo or PR number")
    details = api.get_discussion_details(repo_id=repo_id, discussion_num=pr, repo_type="dataset")
    if not details.is_pull_request or details.status != "open":
        raise ValueError("The discussion must be an open PR")
    sha = api.repo_info(repo_id=repo_id, repo_type="dataset", revision=f"refs/pr/{pr}").sha
    if not isinstance(sha, str) or not re.fullmatch(r"[0-9a-f]{40}", sha):
        raise ValueError("Cannot identify the PR head commit")
    paths = api.list_repo_files(repo_id=repo_id, repo_type="dataset", revision=sha)
    prefixes = {p.rsplit("/", 1)[0] for p in paths if p.startswith("submissions/") and p.count("/") == 2}
    if submission_id is not None:
        prefix = f"submissions/{submission_id}"
        if prefix not in prefixes:
            raise ValueError("Selected submission is not present in this PR")
    elif len(prefixes) == 1:
        prefix = next(iter(prefixes))
    else:
        main_paths = set(api.list_repo_files(repo_id=repo_id, repo_type="dataset", revision="main"))
        changed = []
        for candidate in sorted(prefixes):
            names_to_compare = [f"{candidate}/{name}" for name in ("history.yaml", "session.yaml", "session.json", "manifest.json")]
            if any(name not in main_paths or name not in paths for name in names_to_compare):
                changed.append(candidate)
            elif any(load_file(name, sha) != load_file(name, "main") for name in names_to_compare):
                changed.append(candidate)
        if len(changed) == 1:
            prefix = changed[0]
        elif not prefixes:
            prefix = None
        else:
            raise ValueError("PR changes zero or multiple packages; specify --submission-id")
    names = ("history.yaml", "session.yaml", "session.json", "manifest.json")
    files = ({f"{prefix}/{name}": load_file(f"{prefix}/{name}", sha)
              for name in names if f"{prefix}/{name}" in paths} if prefix else {})
    report = validate_pr_package(files, source_revision=sha)
    evidence: list[dict] = []
    if sources and not report.has_errors:
        history = _yaml_object(files[f"{prefix}/history.yaml"], "history.yaml")
        checked = review_sources(history)
        report.findings.extend(checked.report.findings)
        evidence = checked.evidence
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / f"pr-{pr}-review.json").write_text(json.dumps(report.as_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (out_dir / f"pr-{pr}-review.md").write_text(report.markdown(), encoding="utf-8")
    (out_dir / f"pr-{pr}-evidence.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if comment:
        latest = api.repo_info(repo_id=repo_id, repo_type="dataset", revision=f"refs/pr/{pr}").sha
        if latest != sha:
            raise ValueError("PR changed during review; rerun for the new head")
        marker = f"<!-- ip-law-review:pr={pr}:sha={sha} -->"
        if not any(marker in str(getattr(event, "content", "")) for event in details.events):
            api.comment_discussion(repo_id=repo_id, repo_type="dataset", discussion_num=pr,
                                   comment=marker + "\n" + report.markdown(limit=20))
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-id", required=True)
    selection = parser.add_mutually_exclusive_group(required=True)
    selection.add_argument("--pr", type=int)
    selection.add_argument("--all-open", action="store_true")
    parser.add_argument("--submission-id", help="required if a PR contains several packages")
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--comment", action="store_true", help="post one report per PR head commit")
    parser.add_argument("--sources", action="store_true", help="fetch and compare official source text")
    args = parser.parse_args(argv)
    token = os.environ.get("HF_TOKEN")
    if args.comment and not token:
        parser.error("HF_TOKEN is required for --comment")
    api = HfApi(token=token)
    numbers = [args.pr] if args.pr else [d.num for d in api.get_repo_discussions(
        repo_id=args.repo_id, repo_type="dataset", discussion_type="pull_request", discussion_status="open")]
    failed = False
    for number in numbers:
        def load_file(path: str, revision: str) -> bytes:
            local = hf_hub_download(repo_id=args.repo_id, repo_type="dataset", filename=path,
                                    revision=revision, token=token)
            return Path(local).read_bytes()
        try:
            report = process_pr(args.repo_id, number, api=api, load_file=load_file,
                                out_dir=Path(args.out_dir), comment=args.comment,
                                sources=args.sources, submission_id=args.submission_id)
            print(f"PR #{number}: {report.as_dict()['summary']}")
            failed |= report.has_errors
        except (OSError, ValueError) as exc:
            print(f"PR #{number}: {type(exc).__name__}: {exc}")
            failed = True
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
