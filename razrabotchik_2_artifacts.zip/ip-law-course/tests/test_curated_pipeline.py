import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import yaml

from expert_submissions.package import build_package
from expert_submissions.curated_pipeline import prepare_all, publish_curated


class FakeApi:
    def __init__(self, files, sha):
        self.files = files
        self.sha = sha
        self.commits = []
        self.target_files = {}

    def get_discussion_details(self, **kwargs):
        return SimpleNamespace(status="open", is_pull_request=True)

    def repo_info(self, **kwargs):
        return SimpleNamespace(sha=self.sha)

    def list_repo_files(self, **kwargs):
        if kwargs["repo_id"] == "demo/curated":
            return list(self.target_files)
        return list(self.files)

    def create_commit(self, **kwargs):
        self.commits.append(kwargs)
        for op in kwargs["operations"]:
            self.target_files[op.path_in_repo] = op.path_or_fileobj
        return SimpleNamespace(commit_url="https://huggingface.co/datasets/demo/curated/commit/1")


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        history = {
            "document": {"title": "Demo", "source_url": "https://publication.pravo.gov.ru/Document/View/demo"},
            "amendments": [{"source_url": "https://publication.pravo.gov.ru/Document/View/demo",
                            "changes": [{"change_id": "c1", "article": "1", "description": "Изменение статьи 1",
                                         "source_locator": "статья 1"}]}],
        }
        (root / "history.yaml").write_text(yaml.safe_dump(history, allow_unicode=True))
        (root / "session.yaml").write_text("session_metadata: {}\n")
        (root / "session.json").write_text('{"session_metadata":{}}')
        package = build_package(root / "history.yaml", root / "session.yaml", root / "session.json",
                                submission_id="demo-expert1-20261028", expert_id="expert1")
        self.files = package.files
        self.sha = "a" * 40
        self.source = "Статья 1. Новая норма действует.".encode()
        self.approval = {
            "format_version": 1, "submission_id": package.submission_id,
            "intake_repo_id": "demo/intake", "pr_number": 2, "source_revision": self.sha,
            "approved_by": "test-human", "approved_at": "2026-10-28", "extracted_at": "2026-10-27",
            "accepted_changes": [{"change_id": "c1", "predicate": "изменена", "amending_doc": "ФЗ № 1",
                                  "source_law": "Demo", "norm_id": "demo/ст.1", "effective_date": "2026-02-01",
                                  "source_file": "sources/demo.txt", "source_url": "https://publication.pravo.gov.ru/Document/View/demo",
                                  "source_coord": "статья 1", "source_sha256": hashlib.sha256(self.source).hexdigest(),
                                  "evidence_quote": "Новая норма действует."}],
        }
        self.api = FakeApi(self.files, self.sha)
        self.root = root

    def test_prepares_approved_data_and_publishes_without_duplicates(self):
        data, manifest, sources = prepare_all([self.approval], api=self.api,
                                              load_file=lambda repo, path, sha: self.files[path],
                                              fetcher=lambda url: self.source, work_dir=self.root / "work")
        self.assertEqual(manifest["record_count"], 1)
        self.assertEqual(manifest["build_date"], "2026-10-28")
        self.assertEqual(manifest["input_packages"][0]["files"]["history.yaml"],
                         hashlib.sha256(self.files["submissions/demo-expert1-20261028/history.yaml"]).hexdigest())
        self.assertEqual(sources["sources/demo.txt"], self.source)
        url = publish_curated(data, manifest, sources, target_repo_id="demo/curated",
                              intake_repo_ids={"demo/intake"}, api=self.api,
                              load_target=lambda path: self.api.target_files[path])
        self.assertIn("commit/1", url)
        self.assertEqual(len(self.api.commits), 1)
        publish_curated(data, manifest, sources, target_repo_id="demo/curated",
                        intake_repo_ids={"demo/intake"}, api=self.api,
                        load_target=lambda path: self.api.target_files[path])
        self.assertEqual(len(self.api.commits), 1)

    def test_stale_pr_and_same_intake_target_fail(self):
        self.api.sha = "b" * 40
        with self.assertRaisesRegex(ValueError, "revision"):
            prepare_all([self.approval], api=self.api,
                        load_file=lambda repo, path, sha: self.files[path],
                        fetcher=lambda url: self.source, work_dir=self.root / "work")
        with self.assertRaisesRegex(ValueError, "separate"):
            publish_curated(b"{}\n", {}, {}, target_repo_id="demo/intake",
                            intake_repo_ids={"demo/intake"}, api=self.api,
                            load_target=lambda path: b"")

    def test_existing_source_cannot_be_silently_replaced(self):
        data, manifest, sources = prepare_all([self.approval], api=self.api,
                                              load_file=lambda repo, path, sha: self.files[path],
                                              fetcher=lambda url: self.source, work_dir=self.root / "work")
        self.api.target_files["sources/demo.txt"] = b"different old source"
        with self.assertRaisesRegex(ValueError, "source"):
            publish_curated(data, manifest, sources, target_repo_id="demo/curated",
                            intake_repo_ids={"demo/intake"}, api=self.api,
                            load_target=lambda path: self.api.target_files[path])


if __name__ == "__main__":
    unittest.main()
