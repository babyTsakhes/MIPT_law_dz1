import json
import hashlib
import tempfile
import unittest
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator

from expert_submissions.package import build_package
from expert_submissions.review_validate import validate_pr_package


class ReviewValidationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.history = {
            "document": {"title": "Учебный акт", "source_url": "https://example.org/act"},
            "amendments": [{
                "amendment_id": "act-1", "date": "2026-02-01", "effective_date": None,
                "source_number": "1-ФЗ", "source_url": "https://example.org/amendment",
                "changes": [{"change_id": "change-1", "article": "1", "type": "изменена",
                             "description": "Изменение статьи 1", "source_locator": "статья 2"}],
            }],
            "extraction": {"counts": {"all_records": 1}},
        }
        self.session = {"session_metadata": {"expert_approved": None}}

    def package_files(self):
        (self.root / "history.yaml").write_text(yaml.safe_dump(self.history, allow_unicode=True), encoding="utf-8")
        (self.root / "session.yaml").write_text(yaml.safe_dump(self.session, allow_unicode=True), encoding="utf-8")
        (self.root / "session.json").write_text(json.dumps(self.session), encoding="utf-8")
        return build_package(self.root / "history.yaml", self.root / "session.yaml",
                             self.root / "session.json", submission_id="demo-20261028-expert1",
                             expert_id="expert1").files

    def test_valid_package_has_no_errors_but_needs_expert_review(self):
        report = validate_pr_package(self.package_files())
        self.assertFalse(report.has_errors)
        self.assertEqual(report.submission_id, "demo-20261028-expert1")
        self.assertIn("effective_date", [finding.path.split(".")[-1] for finding in report.findings])
        self.assertIn("needs_expert_review", {finding.severity for finding in report.findings})
        schema = json.loads((Path(__file__).parents[1] / "expert_submissions/review-report.schema.json").read_text())
        self.assertEqual(list(Draft202012Validator(schema).iter_errors(report.as_dict())), [])

    def test_tampered_history_hash_is_error(self):
        files = self.package_files()
        key = next(path for path in files if path.endswith("history.yaml"))
        files[key] += b"\n# changed\n"
        report = validate_pr_package(files)
        self.assertIn("HASH_MISMATCH", {finding.code for finding in report.findings})

    def test_rejects_inconsistent_session_formats(self):
        files = self.package_files()
        key = next(path for path in files if path.endswith("session.json"))
        files[key] = b'{"session_metadata":{"expert_approved":1}}'
        report = validate_pr_package(files)
        self.assertIn("SESSION_MISMATCH", {finding.code for finding in report.findings})
        self.assertIn("session.session_metadata.expert_approved", {finding.path for finding in report.findings})

    def test_bad_calendar_date_and_duplicate_change_id(self):
        self.history["amendments"][0]["date"] = "2026-02-30"
        self.history["amendments"][0]["changes"].append(dict(self.history["amendments"][0]["changes"][0]))
        self.history["extraction"]["counts"]["all_records"] = 2
        report = validate_pr_package(self.package_files())
        self.assertTrue({"INVALID_DATE", "DUPLICATE_CHANGE_ID"}.issubset({f.code for f in report.findings}))

    def test_manifest_status_cannot_claim_approval(self):
        files = self.package_files()
        key = next(path for path in files if path.endswith("manifest.json"))
        manifest = json.loads(files[key])
        manifest["status"] = "approved"
        files[key] = json.dumps(manifest).encode()
        report = validate_pr_package(files)
        self.assertIn("SCHEMA", {finding.code for finding in report.findings})

    def test_report_does_not_echo_credentials(self):
        files = self.package_files()
        key = next(path for path in files if path.endswith("session.json"))
        secret = "ghp_" + "abcdefghijklmnopqrstuvwxyz123456"
        files[key] += secret.encode()
        report = validate_pr_package(files)
        self.assertIn("POSSIBLE_SECRET", {finding.code for finding in report.findings})
        self.assertNotIn(secret, report.markdown())

    def test_rechecks_cross_file_claims_after_hashes_are_recomputed(self):
        files = self.package_files()
        prefix = "submissions/demo-20261028-expert1/"
        history = yaml.safe_load(files[prefix + "history.yaml"])
        history["extraction"]["counts"]["all_records"] = 99
        files[prefix + "history.yaml"] = yaml.safe_dump(history, allow_unicode=True).encode()
        session = {"session_metadata": {"expert_approved": None},
                   "final_result": {"data_sha256": "0" * 64}}
        files[prefix + "session.yaml"] = yaml.safe_dump(session).encode()
        files[prefix + "session.json"] = json.dumps(session).encode()
        manifest = json.loads(files[prefix + "manifest.json"])
        manifest["document_title"] = "Другой документ"
        manifest["source_url"] = "https://example.org/other"
        manifest["files"] = {name: hashlib.sha256(files[prefix + name]).hexdigest()
                             for name in ("history.yaml", "session.yaml", "session.json")}
        files[prefix + "manifest.json"] = json.dumps(manifest).encode()
        codes = {finding.code for finding in validate_pr_package(files).findings}
        self.assertTrue({"COUNT_MISMATCH", "HASH_MISMATCH", "DOCUMENT_MISMATCH"} <= codes)

    def test_unhashable_yaml_key_becomes_parse_finding(self):
        files = self.package_files()
        key = next(path for path in files if path.endswith("history.yaml"))
        files[key] = b"? [a, b]\n: c\n"
        report = validate_pr_package(files)
        self.assertIn("PARSE", {finding.code for finding in report.findings})


if __name__ == "__main__":
    unittest.main()
