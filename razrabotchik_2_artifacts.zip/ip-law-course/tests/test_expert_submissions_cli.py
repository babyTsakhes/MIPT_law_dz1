import json
import io
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import yaml

from expert_submissions.package import Package
from expert_submissions.submit import SubmitError, main, submit_package


class FakeApi:
    def __init__(self, *, status="open", is_pr=True, files=None):
        self.status = status
        self.is_pr = is_pr
        self.files = files or []
        self.commit = None

    def get_discussion_details(self, **kwargs):
        return SimpleNamespace(status=self.status, is_pull_request=self.is_pr)

    def list_repo_files(self, **kwargs):
        return self.files

    def create_commit(self, **kwargs):
        self.commit = kwargs
        return SimpleNamespace(
            pr_url="https://huggingface.co/datasets/demo/intake/discussions/2",
            commit_url="https://huggingface.co/datasets/demo/intake/commit/abc",
        )


class SubmissionTests(unittest.TestCase):
    def setUp(self):
        self.package = Package(
            submission_id="demo-expert1-20261028",
            files={
                "submissions/demo-expert1-20261028/history.yaml": b"document: demo\n",
                "submissions/demo-expert1-20261028/manifest.json": b"{}\n",
            },
            manifest={"status": "proposed"},
        )

    def test_initial_upload_opens_one_pr_with_all_files(self):
        api = FakeApi()
        url = submit_package(self.package, "demo/intake", "secret", api=api)
        self.assertEqual(url, "https://huggingface.co/datasets/demo/intake/discussions/2")
        self.assertTrue(api.commit["create_pr"])
        self.assertIsNone(api.commit.get("revision"))
        self.assertEqual(
            {operation.path_in_repo for operation in api.commit["operations"]},
            set(self.package.files),
        )

    def test_correction_updates_existing_pr(self):
        api = FakeApi(files=["submissions/demo-expert1-20261028/manifest.json"])
        url = submit_package(self.package, "demo/intake", "secret", pr=2, api=api)
        self.assertEqual(url, "https://huggingface.co/datasets/demo/intake/discussions/2")
        self.assertFalse(api.commit["create_pr"])
        self.assertEqual(api.commit["revision"], "refs/pr/2")

    def test_rejects_closed_pr(self):
        api = FakeApi(status="closed", files=["submissions/demo-expert1-20261028/manifest.json"])
        with self.assertRaisesRegex(SubmitError, "open"):
            submit_package(self.package, "demo/intake", "secret", pr=2, api=api)
        self.assertIsNone(api.commit)

    def test_rejects_unrelated_pr(self):
        api = FakeApi(files=["smoke-tests/test.json"])
        with self.assertRaisesRegex(SubmitError, "submission_id"):
            submit_package(self.package, "demo/intake", "secret", pr=2, api=api)
        self.assertIsNone(api.commit)

    def test_dry_run_does_not_request_token_or_call_hub(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            history = root / "history.yaml"
            session_y = root / "session.yaml"
            session_j = root / "session.json"
            history.write_text(yaml.safe_dump({
                "document": {"title": "Test", "source_url": "https://example.org"},
                "amendments": [{"changes": [{"article": "1"}]}],
            }))
            session_y.write_text("session_metadata: {}\n")
            session_j.write_text(json.dumps({"session_metadata": {}}))
            result = main([
                "--history", str(history), "--session-yaml", str(session_y),
                "--session-json", str(session_j), "--submission-id", "demo-expert1-20261028",
                "--expert-id", "expert1", "--repo-id", "demo/intake",
            ], api_factory=lambda token: self.fail("Hub must not be called"))
        self.assertEqual(result, 0)

    def test_reads_non_secret_config_for_dry_run(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            (root / "history.yaml").write_text(yaml.safe_dump({
                "document": {"title": "Test", "source_url": "https://example.org"},
                "amendments": [{"changes": [{"article": "1"}]}],
            }))
            (root / "session.yaml").write_text("session_metadata: {}\n")
            (root / "session.json").write_text('{"session_metadata":{}}')
            config = root / "config.json"
            config.write_text(json.dumps({
                "history": str(root / "history.yaml"),
                "session_yaml": str(root / "session.yaml"),
                "session_json": str(root / "session.json"),
                "submission_id": "demo-expert1-20261028",
                "expert_id": "expert1",
                "repo_id": "demo/intake",
            }))
            result = main(["--config", str(config)], api_factory=lambda token: self.fail("Hub must not be called"))
        self.assertEqual(result, 0)

    def test_rejects_token_in_config(self):
        with tempfile.TemporaryDirectory() as root:
            config = Path(root) / "config.json"
            config.write_text('{"HF_TOKEN":"secret"}')
            self.assertEqual(main(["--config", str(config)]), 1)

    def test_cli_explains_closed_pr_without_echoing_token(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            (root / "history.yaml").write_text(yaml.safe_dump({
                "document": {"title": "Test", "source_url": "https://example.org"},
                "amendments": [{"changes": [{"article": "1"}]}],
            }))
            (root / "session.yaml").write_text("session_metadata: {}\n")
            (root / "session.json").write_text('{"session_metadata":{}}')
            output = io.StringIO()
            token = "dummy-test-token"
            with patch.dict("os.environ", {"HF_TOKEN": token}), redirect_stderr(output), redirect_stdout(io.StringIO()):
                result = main([
                    "--history", str(root / "history.yaml"),
                    "--session-yaml", str(root / "session.yaml"),
                    "--session-json", str(root / "session.json"),
                    "--submission-id", "demo-expert1-20261028",
                    "--expert-id", "expert1", "--repo-id", "demo/intake",
                    "--submit", "--pr", "2",
                ], api_factory=lambda supplied: FakeApi(status="closed"))
            self.assertEqual(result, 1)
            self.assertIn("open PR", output.getvalue())
            self.assertNotIn(token, output.getvalue())


if __name__ == "__main__":
    unittest.main()
