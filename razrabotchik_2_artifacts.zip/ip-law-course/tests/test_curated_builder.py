import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

from expert_submissions.package import build_package
from expert_submissions.curated import ApprovalError, build_curated, convert_approved
from expert_submissions.review_validate import validate_pr_package


class CuratedTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.corpus = self.root / "corpus"
        self.corpus.mkdir()
        (self.corpus / "sources").mkdir()
        self.source = self.corpus / "sources" / "official.txt"
        self.source.write_text("Статья 1. Новая норма действует.", encoding="utf-8")
        history = {
            "document": {"title": "Учебный акт", "source_url": "https://publication.pravo.gov.ru/Document/View/demo"},
            "amendments": [{"amendment_id": "a1", "date": "2026-01-01", "effective_date": "2026-02-01",
                            "source_number": "1-ФЗ", "source_url": "https://publication.pravo.gov.ru/Document/View/demo",
                            "changes": [{"change_id": "c1", "article": "1", "type": "изменена",
                                         "description": "Изменена статья 1.", "source_locator": "статья 1"}]}],
        }
        (self.root / "history.yaml").write_text(yaml.safe_dump(history, allow_unicode=True), encoding="utf-8")
        (self.root / "session.yaml").write_text("session_metadata: {}\n")
        (self.root / "session.json").write_text('{"session_metadata":{}}')
        self.package = build_package(self.root / "history.yaml", self.root / "session.yaml",
                                     self.root / "session.json", submission_id="demo-20261028-expert1",
                                     expert_id="expert1")
        self.sha = "a" * 40
        self.report = validate_pr_package(self.package.files, source_revision=self.sha)
        self.approval = {
            "format_version": 1, "submission_id": self.package.submission_id,
            "intake_repo_id": "demo/intake", "pr_number": 2,
            "source_revision": self.sha, "approved_by": "human-expert",
            "approved_at": "2026-10-28", "extracted_at": "2026-10-28", "accepted_changes": [{
                "change_id": "c1", "predicate": "изменена", "amending_doc": "ФЗ № 1 от 01.01.2026",
                "source_law": "Учебный акт", "norm_id": "учебный-акт/ст.1",
                "effective_date": "2026-02-01", "source_file": "sources/official.txt",
                "source_url": "https://publication.pravo.gov.ru/Document/View/demo",
                "source_coord": "статья 1", "evidence_quote": "Новая норма действует.",
                "source_sha256": hashlib.sha256(self.source.read_bytes()).hexdigest(),
            }],
        }

    def test_approved_change_converts_to_course_record(self):
        records = convert_approved(self.package.files, self.report, self.approval, self.corpus)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["profile"], "amendment")
        self.assertEqual(records[0]["review"]["status"], "verified")
        self.assertEqual(records[0]["source"]["file"], "sources/official.txt")
        self.assertEqual(records[0]["norm"]["norm_id"], "учебный-акт/ст.1")
        jsonl = self.root / "records.jsonl"
        jsonl.write_text(json.dumps(records[0], ensure_ascii=False) + "\n", encoding="utf-8")
        validator = Path(__file__).parents[1] / "assignments/00-first-contribution/dataset-schema/validate.py"
        result = subprocess.run([sys.executable, str(validator), str(jsonl), "--corpus-root", str(self.corpus)],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_stale_approval_and_unmatched_quote_are_rejected(self):
        self.approval["source_revision"] = "b" * 40
        with self.assertRaisesRegex(ApprovalError, "revision"):
            convert_approved(self.package.files, self.report, self.approval, self.corpus)
        self.approval["source_revision"] = self.sha
        self.approval["accepted_changes"][0]["evidence_quote"] = "В источнике этого нет"
        with self.assertRaisesRegex(ApprovalError, "quote"):
            convert_approved(self.package.files, self.report, self.approval, self.corpus)

    def test_source_path_cannot_traverse(self):
        self.approval["accepted_changes"][0]["source_file"] = "sources/../official.txt"
        with self.assertRaisesRegex(ApprovalError, "source_file"):
            convert_approved(self.package.files, self.report, self.approval, self.corpus)

    def test_quote_must_be_near_source_coordinate(self):
        self.approval["accepted_changes"][0]["source_coord"] = "неизвестный пункт"
        with self.assertRaisesRegex(ApprovalError, "coordinate"):
            convert_approved(self.package.files, self.report, self.approval, self.corpus)

    def test_duplicate_legal_change_across_submissions_is_deduplicated(self):
        records = convert_approved(self.package.files, self.report, self.approval, self.corpus)
        data, manifest = build_curated([("one", self.sha, records), ("two", "b" * 40, records)])
        self.assertEqual(len(data.splitlines()), 1)
        self.assertEqual(manifest["record_count"], 1)

    def test_build_is_deterministic_and_provenance_is_recorded(self):
        records = convert_approved(self.package.files, self.report, self.approval, self.corpus)
        first = build_curated([(self.package.submission_id, self.sha, records)])
        second = build_curated([(self.package.submission_id, self.sha, records)])
        self.assertEqual(first, second)
        data, manifest = first
        self.assertEqual(len(data.splitlines()), 1)
        self.assertEqual(manifest["sources"][0]["revision"], self.sha)
        self.assertEqual(manifest["record_count"], 1)
        self.assertEqual(manifest["accepted_record_ids"], [records[0]["record_id"]])
        self.assertIn("validator_version", manifest)


if __name__ == "__main__":
    unittest.main()
