import unittest

from expert_submissions.source_review import review_sources


class SourceReviewTests(unittest.TestCase):
    def history(self, url="https://publication.pravo.gov.ru/Document/View/test"):
        return {"amendments": [{"source_url": url, "source_number": "1-ФЗ", "changes": [
            {"change_id": "c1", "article": "1", "source_locator": "статья 2", "new_text": "Новая норма действует."}
        ]}]}

    def test_exact_quote_creates_evidence_but_still_needs_expert(self):
        calls = []
        def fetch(url):
            calls.append(url)
            return "Статья 2. Новая норма действует.".encode()
        result = review_sources(self.history(), fetcher=fetch, accessed_at="2026-10-28")
        self.assertEqual(len(calls), 1)
        self.assertEqual(result.evidence[0]["match"], "exact")
        self.assertEqual(result.evidence[0]["accessed_at"], "2026-10-28")
        self.assertIn("LEGAL_REVIEW_REQUIRED", {f.code for f in result.report.findings})
        codes = {f.code for f in result.report.findings}
        self.assertIn("CHANGE_TYPE_UNVERIFIED", codes)
        self.assertIn("EFFECTIVE_DATE_UNVERIFIED", codes)
        self.assertIn("EDITION_SEQUENCE_UNVERIFIED", codes)

    def test_non_official_host_is_not_fetched(self):
        result = review_sources(self.history("https://example.org/act"),
                                fetcher=lambda url: self.fail("must not fetch"))
        self.assertIn("NON_OFFICIAL_SOURCE", {f.code for f in result.report.findings})

    def test_quote_mismatch_and_unavailable_are_explicit(self):
        mismatch = review_sources(self.history(), fetcher=lambda url: b"Other text")
        self.assertIn("QUOTE_NOT_FOUND", {f.code for f in mismatch.report.findings})
        unavailable = review_sources(self.history(), fetcher=lambda url: (_ for _ in ()).throw(OSError("private detail")))
        self.assertIn("SOURCE_UNAVAILABLE", {f.code for f in unavailable.report.findings})
        self.assertNotIn("private detail", unavailable.report.markdown())

    def test_missing_act_number_and_article_are_review_questions(self):
        result = review_sources(self.history(), fetcher=lambda url: "Новая норма действует.".encode())
        codes = {finding.code for finding in result.report.findings}
        self.assertIn("ACT_ID_NOT_FOUND", codes)
        self.assertIn("ARTICLE_NOT_FOUND", codes)
        self.assertIn("COMPLETENESS_UNVERIFIED", codes)


if __name__ == "__main__":
    unittest.main()
