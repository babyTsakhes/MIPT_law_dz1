import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import yaml

from expert_submissions.package import PackageError, build_package


class PackageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.history = self.root / "history.yaml"
        self.session_yaml = self.root / "session.yaml"
        self.session_json = self.root / "session.json"
        self.data = {
            "document": {"title": "Учебный акт", "source_url": "https://example.org/act"},
            "amendments": [{"amendment_id": 1, "changes": [{"article": "1"}]}],
            "extraction": {"counts": {"all_records": 1}},
        }
        self.session = {"session_metadata": {"expert_approved": None}}
        self.write_inputs()

    def write_inputs(self):
        self.history.write_text(yaml.safe_dump(self.data, allow_unicode=True))
        self.session_yaml.write_text(yaml.safe_dump(self.session, allow_unicode=True))
        self.session_json.write_text(json.dumps(self.session, ensure_ascii=False))

    def build(self, submission_id="demo-act-expert1-20261028", expert_id="expert1"):
        return build_package(
            self.history, self.session_yaml, self.session_json,
            submission_id=submission_id, expert_id=expert_id,
        )

    def test_packages_three_files_and_manifest_with_hashes(self):
        package = self.build()
        prefix = "submissions/demo-act-expert1-20261028/"
        self.assertEqual(set(package.files), {
            prefix + "history.yaml", prefix + "session.yaml",
            prefix + "session.json", prefix + "manifest.json",
        })
        manifest = json.loads(package.files[prefix + "manifest.json"])
        self.assertEqual(manifest["status"], "proposed")
        self.assertEqual(manifest["expert_id"], "expert1")
        self.assertEqual(manifest["source_url"], "https://example.org/act")
        self.assertEqual(manifest["files"]["history.yaml"], hashlib.sha256(self.history.read_bytes()).hexdigest())

    def test_rejects_mismatched_session_formats(self):
        self.session_json.write_text('{"session_metadata":{"expert_approved":true}}')
        with self.assertRaisesRegex(PackageError, "Session YAML and JSON differ"):
            self.build()

    def test_rejects_session_values_with_different_types(self):
        self.session["session_metadata"]["expert_approved"] = True
        self.write_inputs()
        self.session_json.write_text('{"session_metadata":{"expert_approved":1}}')
        with self.assertRaisesRegex(PackageError, "Session YAML and JSON differ"):
            self.build()

    def test_rejects_secret_without_echoing_it(self):
        secret = "hf_" + "abcdefghijklmnopqrstuvwxyz123456"
        self.session["note"] = secret
        self.write_inputs()
        with self.assertRaises(PackageError) as caught:
            self.build()
        self.assertIn("credential", str(caught.exception))
        self.assertNotIn(secret, str(caught.exception))

    def test_rejects_github_tokens_without_echoing_them(self):
        for secret in ("ghp_" + "abcdefghijklmnopqrstuvwxyz123456", "github_pat_" + "abcdefghijklmnopqrstuvwxyz123456"):
            with self.subTest(prefix=secret.split("_")[0]):
                self.session["note"] = secret
                self.write_inputs()
                with self.assertRaises(PackageError) as caught:
                    self.build()
                self.assertIn("credential", str(caught.exception))
                self.assertNotIn(secret, str(caught.exception))

    def test_rejects_non_object_optional_sections(self):
        for section in ("extraction", "counts", "final_result"):
            with self.subTest(section=section):
                self.data["extraction"] = {"counts": {"all_records": 1}}
                self.session = {"session_metadata": {"expert_approved": None}}
                if section == "extraction":
                    self.data["extraction"] = ["unexpected"]
                elif section == "counts":
                    self.data["extraction"]["counts"] = ["unexpected"]
                else:
                    self.session["final_result"] = ["unexpected"]
                self.write_inputs()
                with self.assertRaisesRegex(PackageError, section):
                    self.build()

    def test_rejects_wrong_history_count(self):
        self.data["extraction"]["counts"]["all_records"] = 2
        self.write_inputs()
        with self.assertRaisesRegex(PackageError, "all_records"):
            self.build()

    def test_rejects_wrong_session_hash(self):
        self.session["final_result"] = {"data_sha256": "0" * 64}
        self.write_inputs()
        with self.assertRaisesRegex(PackageError, "data_sha256"):
            self.build()

    def test_rejects_unsafe_submission_id(self):
        with self.assertRaisesRegex(PackageError, "submission_id"):
            self.build(submission_id="../escape")

    def test_rejects_duplicate_yaml_mapping_key(self):
        self.history.write_text(
            "document:\n  title: First\n  title: Second\n  source_url: https://example.org\n"
            "amendments:\n  - changes:\n      - article: '1'\n"
        )
        with self.assertRaisesRegex(PackageError, "duplicate key"):
            self.build()

    def test_rejects_duplicate_json_mapping_key(self):
        self.session_json.write_text('{"session_metadata":{},"session_metadata":{}}')
        with self.assertRaisesRegex(PackageError, "duplicate key"):
            self.build()

    def test_rejects_history_without_changes(self):
        self.data["amendments"][0]["changes"] = []
        self.data["extraction"]["counts"]["all_records"] = 0
        self.write_inputs()
        with self.assertRaisesRegex(PackageError, "at least one change"):
            self.build()

    def test_rejects_empty_document_title(self):
        self.data["document"]["title"] = ""
        self.write_inputs()
        with self.assertRaisesRegex(PackageError, "document.title"):
            self.build()

    def test_rejects_incomplete_source_url(self):
        self.data["document"]["source_url"] = "https://"
        self.write_inputs()
        with self.assertRaisesRegex(PackageError, "source_url"):
            self.build()


if __name__ == "__main__":
    unittest.main()
