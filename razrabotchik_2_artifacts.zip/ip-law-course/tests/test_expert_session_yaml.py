import json
import tempfile
import unittest
from pathlib import Path

import yaml

from expert_submissions.session_yaml import convert


class SessionYamlTests(unittest.TestCase):
    def test_converts_full_json_object_without_dropping_turns(self):
        with tempfile.TemporaryDirectory() as root:
            source = Path(root) / "session.json"
            target = Path(root) / "session.yaml"
            original = {
                "info": {"id": "ses_demo"},
                "messages": [
                    {"role": "user", "parts": [{"text": "Задание"}]},
                    {"role": "assistant", "parts": [{"text": "Исправленный ответ"}]},
                ],
            }
            source.write_text(json.dumps(original, ensure_ascii=False))
            convert(source, target)
            self.assertEqual(yaml.safe_load(target.read_text()), original)


if __name__ == "__main__":
    unittest.main()
