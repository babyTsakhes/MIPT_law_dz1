import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from expert_submissions.review_worker import process_pr


class FakeApi:
    def __init__(self, files, *, events=None, sha="a" * 40):
        self.files = files
        self.events = events or []
        self.sha = sha
        self.comments = []

    def get_discussion_details(self, **kwargs):
        return SimpleNamespace(status="open", is_pull_request=True, events=self.events)

    def repo_info(self, **kwargs):
        return SimpleNamespace(sha=self.sha)

    def list_repo_files(self, **kwargs):
        return list(self.files) + [".gitattributes"]

    def comment_discussion(self, **kwargs):
        self.comments.append(kwargs["comment"])


class WorkerTests(unittest.TestCase):
    def files(self):
        import yaml
        from expert_submissions.package import build_package
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        (root / "history.yaml").write_text(yaml.safe_dump({
            "document": {"title": "Demo", "source_url": "https://example.org"},
            "amendments": [{"changes": [{"article": "1", "source_locator": "ст.1"}]}],
        }))
        (root / "session.yaml").write_text("session_metadata: {}\n")
        (root / "session.json").write_text('{"session_metadata":{}}')
        return build_package(root / "history.yaml", root / "session.yaml", root / "session.json",
                             submission_id="demo-expert1-20261028", expert_id="expert1").files

    def test_processes_pr_writes_reports_and_comments_once(self):
        files = self.files()
        api = FakeApi(files)
        output = Path(self.temp.name) / "reports"
        result = process_pr("demo/intake", 2, api=api, load_file=lambda path, rev: files[path],
                            out_dir=output, comment=True)
        self.assertTrue((output / "pr-2-review.json").exists())
        self.assertEqual(json.loads((output / "pr-2-review.json").read_text())["source_revision"], api.sha)
        self.assertEqual(len(api.comments), 1)
        api.events.append(SimpleNamespace(content=api.comments[0]))
        process_pr("demo/intake", 2, api=api, load_file=lambda path, rev: files[path],
                   out_dir=output, comment=True)
        self.assertEqual(len(api.comments), 1)
        self.assertEqual(result.submission_id, "demo-expert1-20261028")

    def test_closed_discussion_is_not_processed(self):
        files = self.files()
        api = FakeApi(files)
        api.get_discussion_details = lambda **kwargs: SimpleNamespace(status="closed", is_pull_request=True, events=[])
        with self.assertRaisesRegex(ValueError, "open PR"):
            process_pr("demo/intake", 2, api=api, load_file=lambda path, rev: files[path],
                       out_dir=Path(self.temp.name) / "reports", comment=True)
        self.assertFalse(api.comments)

    def test_missing_manifest_still_reports_and_comments(self):
        files = self.files()
        files = {path: data for path, data in files.items() if not path.endswith("manifest.json")}
        api = FakeApi(files)
        report = process_pr("demo/intake", 2, api=api, load_file=lambda path, rev: files[path],
                            out_dir=Path(self.temp.name) / "reports", comment=True)
        self.assertIn("MISSING_FILES", {finding.code for finding in report.findings})
        self.assertEqual(len(api.comments), 1)

    def test_pr_without_submission_gets_actionable_report(self):
        files = self.files()
        api = FakeApi({})
        report = process_pr("demo/intake", 2, api=api, load_file=lambda path, rev: files[path],
                            out_dir=Path(self.temp.name) / "reports", comment=True)
        self.assertIn("MISSING_FILES", {finding.code for finding in report.findings})
        self.assertEqual(len(api.comments), 1)


if __name__ == "__main__":
    unittest.main()
